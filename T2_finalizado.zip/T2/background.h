#ifndef __BACKGROUND__ // Guardas de inclusão
#define __BACKGROUND__ // Guardas de inclusão

#include <allegro5/allegro.h> // Inclusão necessária para usar ALLEGRO_BITMAP

/*-------------------------------------------------------------------*/
/* PROTÓTIPO DE FUNÇÕES */
void atualiza_e_desenha_background(ALLEGRO_BITMAP *background, float *background_x, float velocidade);

#endif // Guardas de inclusão